# Focused iid surprisal regressions

Both examples strictly compiled with package options, warningAsError and one
Lean thread. Their separately imported named axiom reports use only the standard
axioms. The singular pure-state example proves that the actual moment at t=1 is
one for every tensor power, including zero copies. The empty-index example
proves that zero copies give the scalar vacuum for arbitrary real center and
exponent. No normalization premise is imposed on the empty one-copy matrix.

Only the regression module was built. No production module was rebuilt and no
imported-artifact sweep was performed in this reserved short verification slot.
Production source records are copied from the completed prior exact audit;
they are not represented as a new artifact-hash verification. Commands, logs,
checked regression source and the two named axiom reports are retained here.
