from pathlib import Path
import json,subprocess,os,time,hashlib,re
base=Path('/private/tmp/tnlean-iid-moments');root=base/'regression';e=json.loads((base/'env.json').read_text());env={**os.environ,'LEAN_PATH':str(root)+':'+e['LEAN_PATH']};commands=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,cmd):
 t=time.monotonic();p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True);log=root/(label+'.log');log.write_text(p.stdout+p.stderr);row={'label':label,'command':cmd,'cwd':str(root),'LEAN_PATH':env['LEAN_PATH'],'returncode':p.returncode,'seconds':round(time.monotonic()-t,3),'log_sha256':sha(log)};commands.append(row);(root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,p.returncode,row['seconds'],flush=True);assert p.returncode==0,log.read_text();return log.read_text()
src=root/'SchurLabelIIDRegression.lean';run('strict-build',[e['lean'],*e['options'],'-o',str(src.with_suffix('.olean')),str(src)])
audit=root/'Axioms.lean';audit.write_text('''import SchurLabelIIDRegression
set_option linter.hashCommand false
namespace SchurLabelIIDRegression
#print axioms singular_unit_exponent
#print axioms empty_ambient_zero_copy
end SchurLabelIIDRegression
run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
''');log=run('imported-audit',[e['lean'],*e['options'],str(audit)]);found={}
for m in re.finditer(r"'([^']+)' (?:depends on axioms: \[(.*?)\]|does not depend on any axioms)",log,re.S):
 n,a=m.groups();found[n]=[] if a is None else [x.strip() for x in a.split(',')]
assert len(found)==2;assert all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in found.values())
rows=[];roots=[Path(p) for p in env['LEAN_PATH'].split(':')]
for m in json.loads((root/'imported-modules.json').read_text()):
 rel=Path(m.replace('.','/')+'.olean');p=next((r/rel for r in roots if (r/rel).is_file()),None);assert p,m;rows.append({'module':m,'artifact':str(p),'resolved_artifact':str(p.resolve()),'sha256':sha(p)})
production=json.loads((base/'final-verification-20261008/checked-sources.json').read_text())
for p in production['sources']:assert sha(Path(p['artifact']))==p['artifact_sha256']
(root/'imported-dependencies.json').write_text(json.dumps(rows,indent=2)+'\n');(root/'axiom-dependencies.json').write_text(json.dumps(found,indent=2)+'\n');(root/'checked-sources.json').write_text(json.dumps({'source_revision':None,'source':str(src),'sha256':sha(src),'production_sources':production['sources'],'imported_artifacts':len(rows)},indent=2)+'\n');print('PASS',len(rows),'actual imports',flush=True)
