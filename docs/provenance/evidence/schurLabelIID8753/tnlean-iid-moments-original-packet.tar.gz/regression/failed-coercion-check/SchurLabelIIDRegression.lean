import QICLean.Representation.SchurLabelIIDMoments

noncomputable section
open Matrix
open scoped ComplexOrder MatrixOrder Matrix.Norms.L2Operator

namespace SchurLabelIIDRegression

/-- The unit-exponent trace of a singular pure state is one, rather than the
ambient dimension produced by the incorrect convention `0 ^ 0 = 1`. -/
theorem singular_unit_exponent (k : ℕ) :
    let σ : Matrix Bool Bool ℂ := diagonal (fun b ↦ ((if b then 1 else 0 : ℝ) : ℂ))
    let ρ := finKronecker (fun _ : Fin k ↦ σ)
    (ρ * NormedSpace.exp (-CFC.log ρ)).trace.re = 1 := by
  let σ : Matrix Bool Bool ℂ := diagonal (fun b ↦ ((if b then 1 else 0 : ℝ) : ℂ))
  have hσ : σ.PosSemidef := by
    apply Matrix.posSemidef_diagonal_iff.mpr
    intro b
    cases b <;> simp
  have hl : CFC.log σ = 0 := by
    rw [CFC.log, Matrix.cfc_diagonal (fun b : Bool ↦ if b then 1 else 0) Real.log
      ((Set.finite_range _).continuousOn Real.log)]
    ext i j
    cases i <;> cases j <;> simp
  have hone : (σ * NormedSpace.exp ((1 : ℂ) •
      (-CFC.log σ - (0 : ℂ) • 1))).trace.re = 1 := by
    simp [hl, σ, Matrix.trace, Matrix.diag]
  have h := Matrix.re_trace_mul_exp_centered_neg_log_finKronecker hσ 0 1 k
  rw [hone, one_pow] at h
  simpa only [Nat.cast_zero, mul_zero, Complex.ofReal_zero, zero_smul, sub_zero,
    Complex.ofReal_one, one_smul] using h

/-- Zero copies form the scalar vacuum even if the one-copy index set is empty. -/
theorem empty_ambient_zero_copy (s t : ℝ) :
    let σ : Matrix Empty Empty ℂ := 0
    let ρ := finKronecker (fun _ : Fin 0 ↦ σ)
    (ρ * NormedSpace.exp ((t : ℂ) • (-CFC.log ρ - ((0 : ℝ) * s : ℂ) • 1))).trace.re =
      1 := by
  simpa only [pow_zero] using Matrix.re_trace_mul_exp_centered_neg_log_finKronecker
    (σ := (0 : Matrix Empty Empty ℂ)) Matrix.PosSemidef.zero s t 0

end SchurLabelIIDRegression
