from pathlib import Path
import hashlib,json,re
wt=Path('/Users/siruilu/Local/agentFormalization/QICLean/worktrees/area-law-label-moments');root=Path('/private/tmp/tnlean-iid-moments')
rows=[('QICLean/Algebra/KroneckerFactorPositivity.lean','Matrix.finKronecker_cons'),('QICLean/Analysis/CfcFinKronecker.lean','Matrix.cfc_finKronecker_const'),('QICLean/Representation/SchurLabelIIDMoments.lean','Matrix.re_trace_mul_exp_centered_neg_log_eq_surprisalMoment'),('QICLean/Representation/SchurLabelIIDMoments.lean','Matrix.re_trace_mul_exp_centered_neg_log_finKronecker'),('QICLean/Representation/SchurLabelIIDMoments.lean','TensorPower.log_centered_surprisalMoment_finKronecker_le'),('QICLean/Representation/SchurLabelIIDMoments.lean','TensorPower.log_centered_labelEntropy_finKronecker_le')]
def sha(b):return hashlib.sha256(b).hexdigest()
def tokens(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s[i:i+2]=='/-':depth+=1;i+=2
  elif depth and s[i:i+2]=='-/':depth-=1;i+=2
  elif depth:i+=1
  elif s[i:i+2]=='--':
   j=s.find('\n',i);i=len(s) if j<0 else j
  else:out.append(s[i]);i+=1
 return ''.join(''.join(out).split())
files={p: (wt/p).read_text() for p,_ in rows};manifest=[]
for j,(p,n) in enumerate(rows,1):
 s=(wt/p).read_text();leaf=n.rsplit('.',1)[1];m=re.search(r'^theorem '+re.escape(leaf)+r'\b',s,re.M);assert m,n
 start=s.rfind('/--',0,m.start());assert start>=0
 provenance='Promoted from the existing internal head-tail calculations; both consumers are refactored.' if j==1 else 'Original formalization, no upstream Lean proof text reused.'
 ident=f'8753-qic-schur-iid-{j:02d}'
 notice=f'/-\nProvenance-ID: {ident}\n{provenance}\nDeclaration: {n}\nManuscript: September 24, 2026, comparator:mgf-data and signed-label-moments.\n-/\n\n'
 s=s[:start]+notice+s[start:];(wt/p).write_text(s);manifest.append({'path':p,'declaration':n,'id':ident})
freeze=[]
for p,before in files.items():
 after=(wt/p).read_text();assert tokens(before)==tokens(after)
 freeze.append({'path':p,'before_sha256':sha(before.encode()),'sha256':sha(after.encode()),'noncomment_tokens_unchanged':True})
(root/'declarations.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'source-freeze.json').write_text(json.dumps({'dependency_source_commit':'eedf28aa8f39c5a78971f343a13a289c062ee98a','sources':freeze,'refactored_declarations':['Matrix.finKronecker_posSemidef','Matrix.exists_pi_smul_posSemidef_of_finKronecker_posSemidef']},indent=2)+'\n')
print(json.dumps(freeze,indent=2))
