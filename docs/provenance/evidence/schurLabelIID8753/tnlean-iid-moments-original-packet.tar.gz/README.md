# Independent-copy surprisal and Schur-label moments

This contribution proves the actual tensor-power moment identity used in
OpenAI's September 24, 2026 area-law manuscript, Section 7, lines 75–85 and
227–238, then derives the signed Schur-label moment bound from the stated
one-copy moment hypothesis. It includes singular states, the unit exponent,
and zero copies. No full-rank or nonempty-index assumption is added.

The underlying function is `x * exp(-t * log x)`, with zero contribution at
zero. No unqualified `x^(1-t)` formula is used at `t=1`, and no global logarithm
additivity across a singular tensor product is asserted.

## Sources for adoption

All paths below are relative to
`/Users/siruilu/Local/agentFormalization/QICLean/worktrees/area-law-label-moments`.

| Source | Contribution | SHA256 |
| --- | --- | --- |
| `QICLean/Algebra/KroneckerFactorPositivity.lean` | `Matrix.finKronecker_cons`; two existing proofs refactored to use it | `37536754ee63977d4fc00e33bb331f3d5bc527a8a9946d2eca5fc2851422e79b` |
| `QICLean/Analysis/CfcFinKronecker.lean` | Multiplicative functional calculus for a positive tensor power | `ac0a5f17c195ab5c987891b5868a8b576e41bf948a20fc67edf298b1e942f43b` |
| `QICLean/Representation/SchurLabelIIDMoments.lean` | Four actual moment identities and bounds | `fc24f58eae574103c599503f71b9e3e43cf1cad4a17453faa5a199b9f0685930` |
| `blueprint/src/fragment/schur_label_iid_moments.tex` | Mathematical statements/proofs, all six new public tags | See `blueprint-coverage.json` |
| `docs/tactic_patterns.md` | Promoted head/tail identity and two-occurrence trace candidate | Copy only the final two entries |

The defining-file change is also supplied independently as
`finKronecker-recurrence-refactor.patch`. The recurrence must remain immediately
after the existing finite Kronecker definition: placing it in a dependent
analysis file would create an import cycle for its two prior consumers.
The blueprint fragment is not yet included by an aggregator or rendered.

## Hypotheses and quantifiers

For Hermitian sigma, arbitrary real center s and real t, the one-copy trace is
`exp(-t*s)` times the existing scalar `Entropy.surprisalMoment` of its eigenvalues.
For positive sigma, the centered k-copy trace at center k*s is the kth power of
that one-copy centered trace, for every natural k and every real t.

If sigma has trace one, a one-copy bound
`log M(t) <= t*S(sigma) + C0*B*t^2` gives the actual centered k-copy bound
`C0*k*B*t^2`. The final theorem assumes that one-copy bound for
`|t| <= c0/sqrt B`, with `C0 >= 0`, `c0 > 0`, and `B >= 1`, and concludes
`log Tr(rho_k exp(t(F_k-k*S(sigma)))) <= 2*C0*k*B*t^2 + q^2/2*log(k+1)`
for `|t| <= min(c0,1)/(2*sqrt B)`. It derives positivity, normalization and
copy-permutation invariance of the actual tensor power. It does not assume
a k-copy surprisal bound, label bound, or concentration conclusion.

## Verification

`final-verification-20261008` records exact-source raw Lean checks using the
package options and `warningAsError`; these are not Lake builds. The defining
file, new functional-calculus file and iid file passed in 13.494, 19.140 and
6.761 seconds respectively, all with default heartbeat limits and no diagnostics.
The imported audit passed in 4.347 seconds. All 13 declarations reported only
`propext`, `Classical.choice` and `Quot.sound`: six new declarations, two existing
refactored declarations, and the five unchanged signed/quantitative predecessors.
The audit records 4,722 actual imported artifacts and their hashes. Apart from
the three deliberately rebuilt modules, all import hashes were unchanged during
the final verification. No repository build cache was written.

`declarations.json` lists the six new public declarations and provenance IDs.
`source-freeze.json` records their source hashes and preservation of mathematical
tokens during notice insertion. `canonical-predecessor-sources.json` verifies
that the unchanged earlier two Schur modules equal their canonical source at
`eedf28aa8f39c5a78971f343a13a289c062ee98a`. Their earlier evidence is retained.
The new local source is uncommitted; canonical integration, provenance records,
root imports, full builds and blueprint rendering belong to the adopting owner.

Root independently reviewed all six new declarations and both refactored
proofs and found the statements and arguments faithful to the cited source.
The focused tactic scan found no repeated pattern above its threshold; the
explicit head/tail repetition was removed before that scan.

One initial import snapshot failed because the operating system reported
`Too many open files in system`. Its exact source, command and log are retained
in `failed-verification-file-limit-20261008`; retrying the unchanged sources
succeeded. No operating-system limits or shared caches were changed.

## Focused regressions

`regression-verification-20261008` contains the passing exact-source checks of
two focused tests: a singular pure-state moment at exponent one for every tensor
power, and the zero-copy scalar vacuum on an empty ambient index set for
arbitrary real center and exponent. The corrected source strictly compiled with
explicit `-j1` in 9.466 seconds; its separately imported two-name axiom audit
passed in 3.466 seconds with only standard axioms. This was the assigned short
serial verification slot after the coordinator released it.

Only the regression module was built. No production module was rebuilt and no
imported-artifact sweep was performed. Its production source records come from
the earlier completed audit and are identified as such. The first failed
regression run, which had only cast-normalization errors, remains preserved in
`regression/failed-coercion-check`.
