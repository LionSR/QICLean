from pathlib import Path
import json,subprocess,os,time,hashlib,re,shutil
base=Path('/private/tmp/tnlean-iid-moments');root=base/'regression-verification-20261008';root.mkdir(exist_ok=True)
e=json.loads((base/'env.json').read_text());env={**os.environ,'LEAN_PATH':str(root)+':'+e['LEAN_PATH']};commands=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,cmd):
 t=time.monotonic();p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True);log=root/(label+'.log');log.write_text(p.stdout+p.stderr);row={'label':label,'command':cmd,'cwd':str(root),'LEAN_PATH':env['LEAN_PATH'],'returncode':p.returncode,'seconds':round(time.monotonic()-t,3),'log_sha256':sha(log)};commands.append(row);(root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,p.returncode,row['seconds'],flush=True);assert p.returncode==0,log.read_text();return log.read_text()
src=root/'SchurLabelIIDRegression.lean';shutil.copy2(base/'regression/SchurLabelIIDRegression.lean',src)
run('strict-build',[e['lean'],'-j1',*e['options'],'-o',str(src.with_suffix('.olean')),str(src)])
audit=root/'Axioms.lean';audit.write_text('''import SchurLabelIIDRegression
set_option linter.hashCommand false
namespace SchurLabelIIDRegression
#print axioms singular_unit_exponent
#print axioms empty_ambient_zero_copy
end SchurLabelIIDRegression
''');log=run('imported-audit',[e['lean'],'-j1',*e['options'],str(audit)]);found={}
for m in re.finditer(r"'([^']+)' (?:depends on axioms: \[(.*?)\]|does not depend on any axioms)",log,re.S):
 n,a=m.groups();found[n]=[] if a is None else [x.strip() for x in a.split(',')]
assert set(found)=={'SchurLabelIIDRegression.singular_unit_exponent','SchurLabelIIDRegression.empty_ambient_zero_copy'}
assert all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in found.values())
(root/'axiom-dependencies.json').write_text(json.dumps(found,indent=2)+'\n')
production=json.loads((base/'final-verification-20261008/checked-sources.json').read_text())
(root/'checked-sources.json').write_text(json.dumps({'source_revision':None,'source':str(src),'sha256':sha(src),'production_source_records_from_prior_audit':production['sources'],'production_modules_rebuilt':False,'imported_artifact_sweep_performed':False,'axioms':found,'serial_threads':1},indent=2)+'\n')
(root/'README.md').write_text('''# Focused iid surprisal regressions

Both examples strictly compiled with package options, warningAsError and one
Lean thread. Their separately imported named axiom reports use only the standard
axioms. The singular pure-state example proves that the actual moment at t=1 is
one for every tensor power, including zero copies. The empty-index example
proves that zero copies give the scalar vacuum for arbitrary real center and
exponent. No normalization premise is imposed on the empty one-copy matrix.

Only the regression module was built. No production module was rebuilt and no
imported-artifact sweep was performed in this reserved short verification slot.
Production source records are copied from the completed prior exact audit;
they are not represented as a new artifact-hash verification. Commands, logs,
checked regression source and the two named axiom reports are retained here.
''')
print('END: both focused regressions and named audits PASS; no production rebuild or artifact sweep',flush=True)
