import os,json,subprocess,time,sys
from pathlib import Path
root=Path('/private/tmp/tnlean-iid-moments');e=json.loads((root/'env.json').read_text())
original=Path(sys.argv[1]).resolve();rel=Path(*original.parts[original.parts.index('QICLean')+1:]) if False else Path(str(original).rsplit('/QICLean/',1)[1]);rel=Path('QICLean')/rel
src=root/'src'/rel;src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(original.read_bytes())
cmd=[e['lean'],*e['options'],'-R',str(root/'src'),str(src)]
if '--export' in sys.argv:
 out=root/rel.with_suffix('.olean');out.parent.mkdir(parents=True,exist_ok=True)
 if out.is_symlink():out.unlink()
 cmd[1:1]=['-o',str(out)]
t=time.monotonic();r=subprocess.run(cmd,env={**os.environ,'LEAN_PATH':e['LEAN_PATH']},cwd='/tmp',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(r.stdout,end='');print('exit',r.returncode,'seconds',round(time.monotonic()-t,3));sys.exit(r.returncode)
