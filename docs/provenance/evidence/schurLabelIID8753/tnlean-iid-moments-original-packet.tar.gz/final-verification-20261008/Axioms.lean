import QICLean.Representation.SchurLabelIIDMoments
set_option linter.hashCommand false

namespace Matrix
#print axioms finKronecker_cons
end Matrix

namespace Matrix
#print axioms cfc_finKronecker_const
end Matrix

namespace Matrix
#print axioms re_trace_mul_exp_centered_neg_log_eq_surprisalMoment
end Matrix

namespace Matrix
#print axioms re_trace_mul_exp_centered_neg_log_finKronecker
end Matrix

namespace TensorPower
#print axioms log_centered_surprisalMoment_finKronecker_le
end TensorPower

namespace TensorPower
#print axioms log_centered_labelEntropy_finKronecker_le
end TensorPower

namespace Matrix
#print axioms finKronecker_posSemidef
end Matrix

namespace Matrix
#print axioms exists_pi_smul_posSemidef_of_finKronecker_posSemidef
end Matrix

namespace PermutationRepresentation
#print axioms re_trace_mul_exp_centered_labelEntropy_le
end PermutationRepresentation

namespace PermutationRepresentation
#print axioms re_trace_mul_exp_neg_centered_labelEntropy_le
end PermutationRepresentation

namespace TensorPower
#print axioms centered_labelEntropy_moments_le
end TensorPower

namespace TensorPower
#print axioms log_centered_labelEntropy_moments_le
end TensorPower

namespace TensorPower
#print axioms log_centered_labelEntropy_moments_uniform
end TensorPower

run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
