from pathlib import Path
import os,json,hashlib,subprocess,time,re
base=Path('/private/tmp/tnlean-iid-moments');env=json.loads((base/'env.json').read_text());e={**os.environ,'LEAN_PATH':env['LEAN_PATH']}
wt=Path('/Users/siruilu/Local/agentFormalization/QICLean/worktrees/area-law-label-moments');out=base/'final-verification-20261008';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();freeze=json.loads((base/'source-freeze.json').read_text());manifest=json.loads((base/'declarations.json').read_text())
files=[r['path'] for r in freeze['sources']];names=[r['declaration'] for r in manifest]+freeze['refactored_declarations']
oldnames=[]
for n in ['declarations.json','bounds-declarations.json']:
 oldnames.extend(r['declaration'] for r in json.loads((Path('/private/tmp/tnlean-schur-label-moments')/n).read_text()))
for row in freeze['sources']:assert sha(wt/row['path'])==row['sha256']
oldsha={'SchurLabelMoments':'2d46012278b416ab7d057cc739da49dbc8e4a49923527585043da201e4b21925','SchurLabelMomentBounds':'9845b65181ba4dc234344bc280f08147c4d799d8198abc4be48a7bf9f256e4b0'}
for n,h in oldsha.items():assert sha(wt/'QICLean/Representation'/f'{n}.lean')==h
commands=[]
def run(label,cmd,cwd):
 t=time.monotonic();p=subprocess.run(cmd,cwd=cwd,env=e,capture_output=True,text=True);log=out/(label+'.log');log.write_text(p.stdout+p.stderr)
 row={'label':label,'command':cmd,'cwd':str(cwd),'LEAN_PATH':env['LEAN_PATH'],'returncode':p.returncode,'seconds':round(time.monotonic()-t,3),'log_sha256':sha(log)};commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,p.returncode,row['seconds'],flush=True);assert p.returncode==0,log.read_text();return log.read_text()
roots=[Path(r) for r in env['LEAN_PATH'].split(':')]
def hash_modules(filename):
 rows=[]
 for m in json.loads((out/filename).read_text()):
  rel=Path(m.replace('.','/')+'.olean');p=next((r/rel for r in roots if (r/rel).is_file()),None);assert p,m
  rows.append({'module':m,'artifact':str(p),'resolved_artifact':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size})
 return rows
def write_modules(filename):return '\nrun_cmd do\n  let e ← Lean.getEnv\n  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)\n  IO.FS.writeFile "'+filename+'" (Lean.Json.compress (Lean.Json.arr ns))\n'
f=out/'DependencySnapshot.lean';f.write_text('import QICLean.Representation.SchurLabelIIDMoments\n'+write_modules('before-modules.json'))
run('before-imports',[env['lean'],*env['options'],str(f)],out);before=hash_modules('before-modules.json')
for rel in files:
 src=wt/rel;snap=base/'src'/rel;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(src.read_bytes());artifact=base/Path(rel).with_suffix('.olean');assert not artifact.is_symlink()
 run('strict-'+src.stem,[env['lean'],*env['options'],'-R',str(base/'src'),'-o',str(artifact),str(snap)],out)
s='import QICLean.Representation.SchurLabelIIDMoments\nset_option linter.hashCommand false\n'
for n in names+oldnames:
 ns,leaf=n.rsplit('.',1);s+=f'\nnamespace {ns}\n#print axioms {leaf}\nend {ns}\n'
s+=write_modules('imported-modules.json');f=out/'Axioms.lean';f.write_text(s);log=run('imported-audit',[env['lean'],*env['options'],str(f)],out)
found={}
for m in re.finditer(r"'([^']+)' (?:depends on axioms: \[(.*?)\]|does not depend on any axioms)",log,re.S):
 n,a=m.groups();found[n]=[] if a is None else [x.strip() for x in a.split(',')]
assert set(found)==set(names+oldnames);assert all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in found.values())
after=hash_modules('imported-modules.json');am={r['module']:r['sha256'] for r in after};changed={str(Path(p).with_suffix('')).replace('/','.') for p in files}
for r in before:
 if r['module'] not in changed:assert am[r['module']]==r['sha256'],r['module']
for n,h in oldsha.items():assert sha(wt/'QICLean/Representation'/f'{n}.lean')==h
(out/'axiom-dependencies.json').write_text(json.dumps(found,indent=2)+'\n');(out/'imported-dependencies.json').write_text(json.dumps(after,indent=2)+'\n')
rows=[]
for rel in files:
 src=wt/rel;artifact=base/Path(rel).with_suffix('.olean');target=out/'sources'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(src.read_bytes());rows.append({'path':rel,'source':str(src),'sha256':sha(src),'artifact':str(artifact),'artifact_sha256':sha(artifact)})
(out/'checked-sources.json').write_text(json.dumps({'source_revision':None,'dependency_source_commit':freeze['dependency_source_commit'],'sources':rows,'other_import_hashes_unchanged_during_verification':True,'new_declarations':[r['declaration'] for r in manifest],'refactored_declarations':freeze['refactored_declarations'],'frozen_predecessors_reaudited':oldnames,'frozen_predecessor_source_hashes':oldsha,'imported_artifacts':len(after)},indent=2)+'\n')
print('PASS',len(found),'standard-only declarations;',len(after),'actual imported artifacts',flush=True)
