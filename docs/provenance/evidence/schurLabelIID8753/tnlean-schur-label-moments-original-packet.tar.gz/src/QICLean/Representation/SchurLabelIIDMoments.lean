/-
Copyright (c) 2026 QICLean contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: QICLean contributors
-/
import QICLean.Representation.SchurLabelMomentBounds
import QICLean.Analysis.SurprisalMoment
import QICLean.Analysis.CfcKronecker
import QICLean.Analysis.ReplicaPermutationCovariance
import QICLean.Analysis.Entropy

/-!
# Centered surprisal moments of tensor powers

The trace weight removes the kernel of a density matrix. Consequently its
surprisal moment factors under tensor powers for every real exponent, including
one. This is the independent-copy step in OpenAI's area-law manuscript,
September 24, 2026, `07-comparators.tex`, lines 75–85 and 227–238. In particular,
the spectral convention at line 83 is retained without a full-rank assumption.
-/

noncomputable section
open Matrix
open scoped ComplexOrder MatrixOrder Kronecker Matrix.Norms.L2Operator

namespace Matrix

variable {Ω : Type*} [Fintype Ω] [DecidableEq Ω]

/-- Spectral calculus evaluates the centered surprisal exponential also on a
singular matrix; the subsequent trace weight will remove its kernel. -/
private theorem exp_centered_neg_log_eq_cfc {σ : Matrix Ω Ω ℂ}
    (hσ : σ.IsHermitian) (s t : ℝ) :
    NormedSpace.exp ((t : ℂ) • (-CFC.log σ - (s : ℂ) • 1)) =
      cfc (fun x : ℝ ↦ Real.exp (t * (-Real.log x - s))) σ := by
  have hcont (f : ℝ → ℝ) : ContinuousOn f (spectrum ℝ σ) :=
    σ.finite_real_spectrum.continuousOn f
  have hc : cfc (fun x : ℝ ↦ t * (-Real.log x - s)) σ =
      (t : ℂ) • (-CFC.log σ - (s : ℂ) • 1) := by
    rw [cfc_const_mul _ _ _ (hcont _), cfc_sub _ _ _ (hcont _) (hcont _),
      cfc_neg, cfc_const (R := ℝ) s σ (show IsSelfAdjoint σ from hσ)]
    simp only [CFC.log, Algebra.algebraMap_eq_smul_one, Complex.coe_smul]
  rw [cfc_comp' Real.exp (fun x : ℝ ↦ t * (-Real.log x - s)) σ
    Real.continuous_exp.continuousOn (hcont _) (show IsSelfAdjoint σ from hσ), hc]
  exact (CFC.real_exp_eq_normedSpace_exp (by
    apply Matrix.IsHermitian.smul
    · exact IsSelfAdjoint.log.neg.sub (Matrix.isHermitian_one.smul (by
        change star (s : ℂ) = (s : ℂ)
        simp))
    · change star (t : ℂ) = (t : ℂ)
      simp)).symm

/-- The actual centered trace moment equals the existing scalar surprisal
moment of the eigenvalues. This is the positive-eigenvalue convention of
`07-comparators.tex`, lines 75–85, with an arbitrary center. -/
theorem re_trace_mul_exp_centered_neg_log_eq_surprisalMoment
    {σ : Matrix Ω Ω ℂ} (hσ : σ.IsHermitian) (s t : ℝ) :
    (σ * NormedSpace.exp ((t : ℂ) • (-CFC.log σ - (s : ℂ) • 1))).trace.re =
      Real.exp (-t * s) * Entropy.surprisalMoment hσ.eigenvalues t := by
  rw [exp_centered_neg_log_eq_cfc hσ, hσ.cfc_eq, hσ.self_mul_cfc,
    hσ.trace_cfc_eq_sum]
  simp only [Complex.re_sum, RCLike.ofReal_eq_complex_ofReal, Complex.ofReal_re]
  simp only [Entropy.surprisalMoment, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [show t * (-Real.log (hσ.eigenvalues i) - s) =
    -t * s + t * -Real.log (hσ.eigenvalues i) by ring, Real.exp_add]
  ring

end Matrix
